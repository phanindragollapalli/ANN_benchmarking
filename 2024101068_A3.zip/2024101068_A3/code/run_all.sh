#!/usr/bin/env bash
# ==============================================================================
# One-Command Reproduction Script for Assignment 3
# Benchmarking Approximate Nearest Neighbour Search
#
# Usage:
#   bash run_all.sh           # Full benchmark across all datasets & experiments
#   bash run_all.sh --quick   # Fast benchmark (< 15 mins) on a 100k vector subset
# ==============================================================================

set -e

# Detect script directory (inside code/)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Parse --quick flag
QUICK_FLAG=""
if [ "$1" == "--quick" ]; then
    QUICK_FLAG="--quick"
    echo "=========================================================="
    echo " Running benchmark in --quick mode (< 15 mins reproduction)"
    echo "=========================================================="
else
    echo "=========================================================="
    echo " Running full benchmark (All datasets, sweeps & experiments)"
    echo "=========================================================="
fi

# Locate Python environment (check venv in parent or local, or fallback to python3)
if [ -f "$SCRIPT_DIR/../venv/bin/python" ]; then
    PYTHON="$SCRIPT_DIR/../venv/bin/python"
    PYTEST="$SCRIPT_DIR/../venv/bin/pytest"
elif [ -f "$SCRIPT_DIR/venv/bin/python" ]; then
    PYTHON="$SCRIPT_DIR/venv/bin/python"
    PYTEST="$SCRIPT_DIR/venv/bin/pytest"
else
    PYTHON="python3"
    PYTEST="pytest"
fi

export PYTHONPATH="$SCRIPT_DIR"
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1

echo "Using Python: $PYTHON"
echo "Enforcing strict single-thread execution: OMP_NUM_THREADS=1"

# Prepare results directories
RESULTS_DIR="$SCRIPT_DIR/../results"
mkdir -p "$RESULTS_DIR/figures"
mkdir -p "$RESULTS_DIR/tables"

# If running full benchmark, refresh results.csv to prevent quick-mode pollution
if [ -z "$QUICK_FLAG" ]; then
    if [ -f "$RESULTS_DIR/results.csv" ]; then
        mv "$RESULTS_DIR/results.csv" "$RESULTS_DIR/results_backup_$(date +%Y%m%d_%H%M%S).csv"
    fi
fi

# 1. Run unit tests
echo ""
echo "[Step 1/6] Running unit tests for recall@10 metric..."
$PYTEST tests/test_metrics.py

# 2. Part 1: Exact baseline on SIFT and GloVe
echo ""
echo "[Step 2/6] Running Part 1: Exact search baseline..."
$PYTHON src/exact_baseline.py --dataset sift $QUICK_FLAG
$PYTHON src/exact_baseline.py --dataset glove $QUICK_FLAG

# 3. Part 2: Standard benchmarks on SIFT
echo ""
echo "[Step 3/6] Running Part 2: Benchmarking SIFT-1M..."
$PYTHON src/index_benchmarks.py --dataset sift $QUICK_FLAG --output_dir "$RESULTS_DIR"

# 4. Part 2: Standard benchmarks on GloVe-100
echo ""
echo "[Step 4/6] Running Part 2: Benchmarking GloVe-100..."
$PYTHON src/index_benchmarks.py --dataset glove $QUICK_FLAG --output_dir "$RESULTS_DIR"

# 5. Generate Part 2 summary tables
echo ""
echo "[Step 5/6] Generating Part 2 tables..."
$PYTHON src/generate_tables.py --csv "$RESULTS_DIR/results.csv" --output "$RESULTS_DIR/tables"

# 6. Part 3 & Part 4 Experiments
echo ""
echo "[Step 6/6] Running Part 3 (Query Difficulty) & Part 4 (Dimensionality Curse)..."
$PYTHON src/query_difficulty.py $QUICK_FLAG --output_dir "$RESULTS_DIR"
$PYTHON src/hard_data_experiment.py $QUICK_FLAG --output_dir "$RESULTS_DIR"

echo ""
echo "=========================================================="
echo " All benchmarks, figures, and tables regenerated successfully!"
echo " Results saved to: $RESULTS_DIR"
echo " Figures saved to: $RESULTS_DIR/figures/"
echo " Tables saved to:  $RESULTS_DIR/tables/"
echo "=========================================================="
