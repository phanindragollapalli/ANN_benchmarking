# CS4.406: Benchmarking Approximate Nearest Neighbour Search

This repository contains the benchmarking suite for evaluating Approximate Nearest Neighbor (ANN) search algorithms (**HNSW**, **IVF-Flat**, **IVF-PQ**) against an exact FAISS baseline on **SIFT-1M** and **GloVe-100** datasets, as well as controlled experiments on query difficulty and synthetic dimensional stress testing.

## System Requirements & Specifications
- **Operating System**: Linux x86_64
- **Python**: >= 3.10 (Tested on Python 3.14)
- **Dependencies**: `faiss-cpu`, `numpy`, `h5py`, `matplotlib`, `pytest`

## Setup Instructions

1. **Create and activate a virtual environment**:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

2. **One-Command Reproduction**:
   - To reproduce all numbers, plots, and tables in the report:
     ```bash
     bash run_all.sh
     ```
   - To run a fast verification on a subset in under 15 minutes:
     ```bash
     bash run_all.sh --quick
     ```

## Project Structure
- `src/`: Core implementation modules (data loading, metrics, exact search, index benchmarking, synthetic data generation).
- `tests/`: Pytest test suite for custom metrics, tie-breaking, and index validation.
- `experiments/`: Dedicated benchmark scripts for Parts 1, 2, 3, and 4.
- `hypothesis.md`: Hypotheses for Parts 3 and 4, committed prior to running experiments.
- `run_all.sh`: Top-level runner script supporting full and `--quick` modes.
