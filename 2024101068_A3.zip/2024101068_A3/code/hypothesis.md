# Hypotheses for Parts 3 & 4

This document records the pre-experiment hypotheses for Part 3 and Part 4 before running experiments, as required by the assignment guidelines. Each hypothesis was committed to git prior to conducting the respective experiment and generating the reported numbers.

---

## Part 3 Hypothesis: Query Difficulty on GloVe-100

### Hypothesis:
> *Queries with low relative contrast (where the distance to the 10th nearest neighbor is close to the distance to the 1st neighbor or the global mean distance) will exhibit significantly lower recall across all approximate indexes. Graph-based indexes (HNSW) will degrade less severely than inverted-file indexes (IVF-Flat) on hard queries because graph routing can traverse local cluster bridges, whereas IVF partitions vectors into rigid Voronoi cells that miss neighbors lying near boundary facets.*

### Evaluation Strategy:
- Metric: Relative Contrast $RC(q) = \frac{D_{\text{mean}}(q)}{D_1(q)}$ or Relative Margin $\Delta_{10,1}(q) = \frac{D_{10}(q) - D_1(q)}{D_1(q)}$.
- Partition the 5,000 test queries into 4 difficulty quartiles (Q1: Hardest to Q4: Easiest).
- Benchmark Recall@10 across each quartile for HNSW, IVF-Flat, and IVF-PQ at standard operating points.

---

## Part 4 Hypothesis: Custom Hard Data Distribution (Distance Concentration)

### Hypothesis:
> *As the intrinsic dimensionality of uniformly distributed synthetic data increases (from $d=16$ to $d=256$), the ratio between the maximum and minimum distance converges to 1 ($\lim_{d \to \infty} \frac{D_{\text{max}} - D_{\text{min}}}{D_{\text{min}}} \to 0$, distance concentration). Under this condition, IVF-Flat will suffer a severe recall collapse because cluster centroids lose their representative partition capability, causing ground truth neighbors to disperse across almost all Voronoi cells. In contrast, HNSW will experience a search latency explosion (QPS collapse) as greedy graph routing degrades toward random walk traversal.*

### Evaluation Strategy:
- Seeded synthetic generator (`SEED=42`) producing 200,000 base vectors and 2,000 queries on unit hyper-spheres $S^{d-1}$ across 4 dimensions: $d \in \{16, 64, 128, 256\}$ ($d=16$ as control).
- Compare recall drop and QPS penalty for HNSW vs IVF-Flat.
