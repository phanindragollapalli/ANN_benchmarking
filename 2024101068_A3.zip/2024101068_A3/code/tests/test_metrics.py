"""
Unit tests for recall@k with tie handling.
"""

import numpy as np
import pytest
from src.metrics import recall_at_k

def test_perfect_match():
    # Exactly matching IDs
    ret_ids = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    gt_ids = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert recall_at_k(ret_ids, gt_ids, k=10) == 1.0

def test_complete_mismatch():
    # Disjoint IDs
    ret_ids = np.array([10, 11, 12, 13, 14, 15, 16, 17, 18, 19])
    gt_ids = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert recall_at_k(ret_ids, gt_ids, k=10) == 0.0

def test_permutation_invariance():
    # Permuted order should still yield recall 1.0
    ret_ids = np.array([9, 8, 7, 6, 5, 4, 3, 2, 1, 0])
    gt_ids = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert recall_at_k(ret_ids, gt_ids, k=10) == 1.0

def test_partial_match():
    # 7 out of 10 match
    ret_ids = np.array([0, 1, 2, 3, 4, 5, 6, 100, 101, 102])
    gt_ids = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert pytest.approx(recall_at_k(ret_ids, gt_ids, k=10), rel=1e-5) == 0.7

def test_tie_at_tenth_neighbor():
    # ID at position 10 differs, but distance is exactly equal to the 10th neighbor distance.
    # Without tie-handling: recall = 9/10 = 0.9
    # With tie-handling: recall = 10/10 = 1.0
    gt_ids = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    gt_dists = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])

    ret_ids = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 999])  # 999 is tied with 9
    ret_dists = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])  # Same distance 1.0

    # With distance tie-handling
    recall_with_tie = recall_at_k(ret_ids, gt_ids, ret_dists, gt_dists, k=10)
    assert recall_with_tie == 1.0

    # If distance was strictly greater than 10th neighbor distance, it is NOT a valid tie
    ret_dists_worse = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.05])
    recall_worse = recall_at_k(ret_ids, gt_ids, ret_dists_worse, gt_dists, k=10)
    assert pytest.approx(recall_worse, rel=1e-5) == 0.9

def test_batch_queries():
    # Multiple queries
    ret_ids = np.array([
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        [0, 1, 2, 3, 4, 10, 11, 12, 13, 14]
    ])
    gt_ids = np.array([
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    ])
    # Query 0: 10/10 = 1.0, Query 1: 5/10 = 0.5 -> Mean = 0.75
    assert pytest.approx(recall_at_k(ret_ids, gt_ids, k=10), rel=1e-5) == 0.75
