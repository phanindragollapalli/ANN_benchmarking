"""
Part 1: Exact search baseline with FAISS.
- Builds IndexFlatL2 reference index.
- Verifies exact results against stored ground truth using recall@10.
- Times search: one query at a time vs batch of all queries.
- Runs in strict single-threaded mode.
"""

import os
import sys
import time
import faiss
import numpy as np

# Add code directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from src.data_loader import load_dataset
from src.metrics import recall_at_k

def run_exact_baseline(dataset_name: str = "sift", quick: bool = False):
    """
    Builds exact IndexFlatL2, verifies against ground truth,
    and benchmarks sequential vs batch query latency.
    """
    # Enforce single thread
    faiss.omp_set_num_threads(1)
    os.environ["OMP_NUM_THREADS"] = "1"
    os.environ["OPENBLAS_NUM_THREADS"] = "1"

    print(f"\n{'='*20} Part 1: Exact Baseline ({dataset_name.upper()}) {'='*20}")
    data = load_dataset(dataset_name, quick=quick)
    train_vecs = data["train"]
    test_queries = data["test_queries"]
    test_gt = data["test_neighbors"]
    test_dists = data["test_distances"]
    dim = data["dimension"]
    num_queries = len(test_queries)

    # 1. Build FAISS exact index (IndexFlatL2)
    print(f"Building FAISS IndexFlatL2 for {len(train_vecs):,} vectors of dimension {dim}...")
    t0 = time.perf_counter()
    index = faiss.IndexFlatL2(dim)
    index.add(train_vecs)
    build_time = time.perf_counter() - t0
    print(f"Index built in {build_time:.3f} s.")

    # Warmup
    _ = index.search(test_queries[:10], 10)

    # 2. Sequential timing: one query at a time
    print(f"Running sequential search (1 query at a time) over {num_queries:,} queries...")
    retrieved_ids_seq = np.empty((num_queries, 10), dtype=np.int64)
    retrieved_dists_seq = np.empty((num_queries, 10), dtype=np.float32)

    # Use 3 runs for quick subset, 1 full pass for 5,000 queries to avoid redundant waiting
    n_seq_runs = 3 if quick else 1
    seq_times = []
    for run in range(n_seq_runs):
        t_start = time.perf_counter()
        for i in range(num_queries):
            q = test_queries[i : i + 1]
            d, ids = index.search(q, 10)
            if run == 0:
                retrieved_dists_seq[i] = d[0]
                retrieved_ids_seq[i] = ids[0]
        seq_times.append(time.perf_counter() - t_start)
    seq_time = float(np.median(seq_times))
    seq_qps = num_queries / seq_time
    seq_latency_ms = (seq_time / num_queries) * 1000.0

    print(f"Sequential Search: Time = {seq_time:.3f} s | QPS = {seq_qps:.1f} | Latency = {seq_latency_ms:.2f} ms/query")

    # 3. Batch timing: all queries in one call
    print(f"Running batch search (all {num_queries:,} queries in 1 batch)...")
    n_batch_runs = 3
    batch_times = []
    for run in range(n_batch_runs):
        t_start = time.perf_counter()
        retrieved_dists_batch, retrieved_ids_batch = index.search(test_queries, 10)
        batch_times.append(time.perf_counter() - t_start)
    batch_time = float(np.median(batch_times))
    batch_qps = num_queries / batch_time
    batch_latency_ms = (batch_time / num_queries) * 1000.0

    print(f"Batch Search:      Time = {batch_time:.3f} s | QPS = {batch_qps:.1f} | Latency = {batch_latency_ms:.2f} ms/query")
    speedup = batch_qps / seq_qps
    print(f"Speedup of Batch vs. Sequential: {speedup:.2f}x")

    # 4. Check agreement with ground truth
    # FAISS IndexFlatL2 returns squared Euclidean distances.
    # - For SIFT: HDF5 distances are unsquared Euclidean -> np.sqrt(retrieved_dists)
    # - For GloVe: HDF5 distances are angular (cosine dist) -> retrieved_dists / 2.0
    if dataset_name == "sift":
        scaled_retrieved_dists = np.sqrt(np.maximum(retrieved_dists_seq, 0.0))
    elif dataset_name == "glove":
        scaled_retrieved_dists = retrieved_dists_seq / 2.0
    else:
        scaled_retrieved_dists = retrieved_dists_seq

    recall = recall_at_k(
        retrieved_ids_seq,
        test_gt,
        scaled_retrieved_dists,
        test_dists,
        k=10,
        eps=1e-3,
    )
    print(f"Agreement with Stored Ground Truth (Recall@10): {recall * 100:.2f}%")

    # 5. Mechanistic explanation
    explanation = (
        f"Why Batch Search ({batch_qps:.1f} QPS) is {speedup:.1f}x faster than Sequential ({seq_qps:.1f} QPS):\n"
        "1. BLAS GEMM vs GEMV: Batch search computes distances using Matrix-Matrix multiplication (GEMM), "
        "which achieves high arithmetic intensity through register tiling and SIMD vectorization, whereas sequential "
        "search performs Matrix-Vector products (GEMV) bottlenecked by memory latency.\n"
        "2. Cache Locality & Memory Bandwidth: In sequential mode, the entire base dataset must be re-read from DRAM for every "
        "query. In batch mode, blocks of the database loaded into L2/L3 cache are simultaneously evaluated against all queries, "
        "drastically cutting DRAM bandwidth consumption.\n"
        "3. Overhead: Batching avoids 5,000 separate Python/C++ function call boundaries and per-query heap allocations."
    )
    print("\n" + explanation)

    return {
        "dataset": dataset_name,
        "build_time_s": build_time,
        "seq_time_s": seq_time,
        "seq_qps": seq_qps,
        "batch_time_s": batch_time,
        "batch_qps": batch_qps,
        "speedup": speedup,
        "recall_at_10": recall,
        "explanation": explanation,
    }

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="sift", choices=["sift", "glove"])
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()
    run_exact_baseline(dataset_name=args.dataset, quick=args.quick)
