"""
Generates the required summary tables for Part 2 using standard library:
1. QPS at Recall 0.90 and 0.95.
2. Build time, Index Size (MB), and Bytes per vector at Recall 0.95.
"""

import os
import csv
from collections import defaultdict

def generate_part2_tables(csv_path: str = "results/results.csv", output_dir: str = "results/tables"):
    if not os.path.exists(csv_path):
        print(f"File {csv_path} does not exist.")
        return

    os.makedirs(output_dir, exist_ok=True)

    # Read rows
    rows_by_dataset = defaultdict(list)
    with open(csv_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if not row.get("recall_10") or row["recall_10"] == "recall_10":
                continue
            try:
                row["recall_10"] = float(row["recall_10"])
                row["qps"] = float(row["qps"])
                row["build_time_s"] = float(row["build_time_s"])
                row["index_size_mb"] = float(row["index_size_mb"])
                row["bytes_per_vector"] = float(row["bytes_per_vector"])
                rows_by_dataset[row["dataset"]].append(row)
            except ValueError:
                continue

    for dataset, rows in rows_by_dataset.items():
        # Filter for full dataset runs if mixed runs exist in CSV
        # SIFT full is 1,000,000; GloVe full is 1,183,514. Quick runs are 100,000.
        max_vecs = max((float(r.get("num_vectors", 0)) for r in rows), default=0)
        if max_vecs > 0:
            full_rows = [r for r in rows if float(r.get("num_vectors", 0)) == max_vecs]
            if full_rows:
                rows = full_rows
        else:
            # Fallback heuristic: exclude known 100k subset sizes if full runs exist
            full_candidates = [r for r in rows if r["index_size_mb"] > 100.0]
            if full_candidates:
                rows = [r for r in rows if r["index_size_mb"] > 100.0 or (r["index_type"] == "IVF-PQ" and r["recall_10"] > 0.65)]

        print(f"\n{'='*25} Summary Tables for {dataset.upper()} ({len(rows)} data points) {'='*25}")

        # Table 1: QPS at Recall 0.90 and 0.95
        print("\n--- Table 1: QPS at Recall 0.90 and 0.95 ---")
        t1_header = "| Index | QPS @ Recall 0.90 | QPS @ Recall 0.95 |"
        t1_sep = "|---|---|---|"
        t1_lines = [t1_header, t1_sep]

        for itype in ["HNSW", "IVF-Flat", "IVF-PQ"]:
            i_rows = [r for r in rows if r["index_type"] == itype]
            if not i_rows:
                continue

            r90_rows = [r for r in i_rows if r["recall_10"] >= 0.90]
            qps_90_str = f"{max(r['qps'] for r in r90_rows):,.1f}" if r90_rows else "N/A (<0.90)"

            r95_rows = [r for r in i_rows if r["recall_10"] >= 0.95]
            qps_95_str = f"{max(r['qps'] for r in r95_rows):,.1f}" if r95_rows else "N/A (<0.95)"

            t1_lines.append(f"| {itype} | {qps_90_str} | {qps_95_str} |")

        t1_text = "\n".join(t1_lines)
        print(t1_text)
        with open(os.path.join(output_dir, f"{dataset}_qps_table.md"), "w") as f:
            f.write(t1_text + "\n")

        # Table 2: Build Time, Index Size, Bytes/Vector at Recall >= 0.95
        print("\n--- Table 2: Build Time and Memory at Recall >= 0.95 ---")
        t2_header = "| Index | Build Time (s) | Index Size (MB) | Bytes / Vector | Recall Achieved |"
        t2_sep = "|---|---|---|---|---|"
        t2_lines = [t2_header, t2_sep]

        for itype in ["HNSW", "IVF-Flat", "IVF-PQ"]:
            i_rows = [r for r in rows if r["index_type"] == itype]
            if not i_rows:
                continue

            r95_rows = [r for r in i_rows if r["recall_10"] >= 0.95]
            if r95_rows:
                best_r = max(r95_rows, key=lambda x: x["qps"])
                t2_lines.append(f"| {itype} | {best_r['build_time_s']:.2f} s | {best_r['index_size_mb']:.2f} MB | {best_r['bytes_per_vector']:.1f} B | {best_r['recall_10']:.4f} |")
            else:
                max_r = max(i_rows, key=lambda x: x["recall_10"])
                t2_lines.append(f"| {itype} | {max_r['build_time_s']:.2f} s | {max_r['index_size_mb']:.2f} MB | {max_r['bytes_per_vector']:.1f} B | {max_r['recall_10']:.4f} (Max < 0.95) |")

        t2_text = "\n".join(t2_lines)
        print(t2_text)
        with open(os.path.join(output_dir, f"{dataset}_cost_table.md"), "w") as f:
            f.write(t2_text + "\n")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", default="results/results.csv", help="Path to results.csv")
    parser.add_argument("--output", default="results/tables", help="Directory for tables")
    args = parser.parse_args()
    generate_part2_tables(csv_path=args.csv, output_dir=args.output)
