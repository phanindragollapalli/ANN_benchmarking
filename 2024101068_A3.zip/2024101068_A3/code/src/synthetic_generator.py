"""
Deterministic synthetic data generator for Part 4 experiment.
Studies the curse of dimensionality and distance concentration.
Generates uniform spherical vectors across dimensions d in [16, 64, 128, 256].
"""

import numpy as np
import faiss

def generate_synthetic_dataset(n_base: int = 100000, n_queries: int = 1000, d: int = 64, seed: int = 42):
    """
    Generates synthetic vectors uniformly on the unit sphere S^{d-1}.
    Computes exact ground truth top-10 neighbors and distances.
    """
    rng = np.random.RandomState(seed)
    
    # Generate Gaussian vectors and normalize to unit sphere
    raw_base = rng.randn(n_base, d).astype(np.float32)
    base_norms = np.linalg.norm(raw_base, axis=1, keepdims=True)
    base_vecs = raw_base / np.maximum(base_norms, 1e-7)

    raw_queries = rng.randn(n_queries, d).astype(np.float32)
    q_norms = np.linalg.norm(raw_queries, axis=1, keepdims=True)
    query_vecs = raw_queries / np.maximum(q_norms, 1e-7)

    # Compute exact ground truth using FAISS IndexFlatL2
    gt_index = faiss.IndexFlatL2(d)
    gt_index.add(base_vecs)
    gt_dists, gt_neighbors = gt_index.search(query_vecs, 100)

    # Convert squared Euclidean to Euclidean distances
    gt_dists = np.sqrt(np.maximum(gt_dists, 0.0))

    # Calculate distance contrast / spread: (D_max - D_min) / D_min
    # Sample 100 queries to compute average max/min distance ratio across all base vectors
    sample_queries = query_vecs[:100]
    d_min = gt_dists[:100, 0]
    # For unit vectors: ||q - v||^2 = 2 - 2*(q . v). Max distance corresponds to min dot product.
    dots = np.dot(sample_queries, base_vecs.T)
    min_dots = np.min(dots, axis=1)
    d_max = np.sqrt(np.maximum(2.0 - 2.0 * min_dots, 0.0))
    rel_spread = float(np.mean((d_max - d_min) / np.maximum(d_min, 1e-6)))

    return {
        "train": base_vecs,
        "test_queries": query_vecs,
        "test_neighbors": gt_neighbors,
        "test_distances": gt_dists,
        "dimension": d,
        "relative_spread": rel_spread,
    }

if __name__ == "__main__":
    for d in [16, 64, 128, 256]:
        data = generate_synthetic_dataset(10000, 100, d=d)
        print(f"Dimension {d:3d}: Relative distance spread (D_max - D_min) / D_min = {data['relative_spread']:.4f}")
