"""
Part 3: Query Difficulty Experiment on GloVe-100.
- Measures query difficulty using Relative Contrast (RC): D_10(q) / D_1(q) or D_mean(q) / D_1(q).
- Partitions queries into 4 difficulty quartiles (Q1: Hardest to Q4: Easiest).
- Evaluates Recall@10 for HNSW, IVF-Flat, and IVF-PQ across the 4 quartiles.
- Generates a comparison plot and summary table for the report.
"""

import os
import sys
import time
import faiss
import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from src.data_loader import load_dataset
from src.metrics import recall_at_k
from src.index_benchmarks import build_index, search_index

# Single thread enforcement
faiss.omp_set_num_threads(1)
os.environ["OMP_NUM_THREADS"] = "1"

def compute_query_difficulty(gt_distances: np.ndarray) -> np.ndarray:
    """
    Computes Relative Contrast for each query:
    RC(q) = D_10(q) / D_1(q)
    Low RC means nearest neighbor is barely closer than the 10th neighbor (ambiguous/hard).
    High RC means nearest neighbor is distinct and well-separated (easy).
    """
    d1 = np.maximum(gt_distances[:, 0], 1e-6)
    # Use distance of 10th neighbor (or last stored neighbor if < 10)
    k_idx = min(9, gt_distances.shape[1] - 1)
    dk = gt_distances[:, k_idx]
    rc = dk / d1
    return rc

def run_query_difficulty_experiment(quick: bool = False, output_dir: str = "results"):
    print("\n" + "=" * 25 + " Part 3: Query Difficulty on GloVe-100 " + "=" * 25)
    os.makedirs(os.path.join(output_dir, "figures"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "tables"), exist_ok=True)

    data = load_dataset("glove", quick=quick)
    train_vecs = data["train"]
    queries = data["test_queries"]
    gt_neighbors = data["test_neighbors"]
    gt_distances = data["test_distances"]
    d = data["dimension"]
    num_queries = len(queries)

    # 1. Compute difficulty metric for each query
    rc_scores = compute_query_difficulty(gt_distances)

    # 2. Group queries into 4 quartiles: Q1 (Hardest) to Q4 (Easiest)
    q_bounds = np.percentile(rc_scores, [25, 50, 75])
    bin_indices = {
        "Q1 (Hardest)": np.where(rc_scores <= q_bounds[0])[0],
        "Q2 (Med-Hard)": np.where((rc_scores > q_bounds[0]) & (rc_scores <= q_bounds[1]))[0],
        "Q3 (Med-Easy)": np.where((rc_scores > q_bounds[1]) & (rc_scores <= q_bounds[2]))[0],
        "Q4 (Easiest)": np.where(rc_scores > q_bounds[2])[0],
    }

    print("\nQuery Difficulty Quartiles (Relative Contrast D_10 / D_1):")
    for bname, idxs in bin_indices.items():
        sub_rc = rc_scores[idxs]
        print(f"  {bname:14s}: {len(idxs):,} queries | Mean RC = {sub_rc.mean():.4f} | Range = [{sub_rc.min():.4f}, {sub_rc.max():.4f}]")

    # 3. Build indexes at representative operating points
    print("\nBuilding indexes for comparison...")
    idx_hnsw, _, _, _ = build_index("HNSW", d, train_vecs, {"M": 16, "efConstruction": 40})
    idx_ivfflat, _, _, _ = build_index("IVF-Flat", d, train_vecs, {"nlist": 256 if quick else 1024})
    idx_ivfpq, _, _, _ = build_index("IVF-PQ", d, train_vecs, {"nlist": 256 if quick else 1024, "m_pq": 10, "nbits": 8})

    # Search parameters targeting standard operating points
    index_runs = {
        "HNSW (efS=40)": (idx_hnsw, "HNSW", 40),
        "IVF-Flat (npr=16)": (idx_ivfflat, "IVF-Flat", 16),
        "IVF-PQ (npr=16)": (idx_ivfpq, "IVF-PQ", 16),
    }

    results_by_bin = {bname: {} for bname in bin_indices.keys()}
    overall_recalls = {}

    for label, (idx, itype, sparam) in index_runs.items():
        print(f"Searching {label}...")
        ids, dists, _, _ = search_index(idx, itype, queries, sparam, k=10, reps=1)
        scaled_dists = dists / 2.0
        overall_rec = recall_at_k(ids, gt_neighbors, scaled_dists, gt_distances, k=10, eps=1e-3)
        overall_recalls[label] = overall_rec

        for bname, b_idxs in bin_indices.items():
            bin_ids = ids[b_idxs]
            bin_gt = gt_neighbors[b_idxs]
            bin_dists = scaled_dists[b_idxs]
            bin_gt_dists = gt_distances[b_idxs]
            bin_rec = recall_at_k(bin_ids, bin_gt, bin_dists, bin_gt_dists, k=10, eps=1e-3)
            results_by_bin[bname][label] = bin_rec

    # 4. Display and save table
    print("\n--- Recall@10 across Query Difficulty Bins ---")
    header = "| Index | Overall Recall | Q1 (Hardest) | Q2 (Med-Hard) | Q3 (Med-Easy) | Q4 (Easiest) | Spread (Q4 - Q1) |"
    sep = "|---|---|---|---|---|---|---|"
    lines = [header, sep]

    for label in index_runs.keys():
        row_str = f"| {label} | {overall_recalls[label]:.4f} | "
        q_vals = [results_by_bin[bname][label] for bname in bin_indices.keys()]
        spread = q_vals[3] - q_vals[0]
        row_str += " | ".join(f"{v:.4f}" for v in q_vals)
        row_str += f" | +{spread:.4f} |"
        lines.append(row_str)

    table_text = "\n".join(lines)
    print(table_text)

    table_path = os.path.join(output_dir, "tables", "glove_query_difficulty.md")
    with open(table_path, "w") as f:
        f.write(table_text + "\n")
    print(f"\nSaved difficulty table to {table_path}")

    # 5. Plot bar chart
    fig, ax = plt.subplots(figsize=(8, 5))
    x = np.arange(len(bin_indices))
    width = 0.25

    colors = ["#1f77b4", "#2ca02c", "#ff7f0e"]
    for i, (label, col) in enumerate(zip(index_runs.keys(), colors)):
        y_vals = [results_by_bin[bname][label] for bname in bin_indices.keys()]
        ax.bar(x + i * width, y_vals, width, label=label, color=col, alpha=0.85)

    ax.set_xlabel("Query Difficulty Quartile", fontsize=12)
    ax.set_ylabel("Recall@10", fontsize=12)
    ax.set_title("Part 3: Recall@10 vs. Query Difficulty on GloVe-100", fontsize=13, fontweight="bold")
    ax.set_xticks(x + width)
    ax.set_xticklabels(list(bin_indices.keys()))
    ax.set_ylim(0, 1.05)
    ax.grid(axis="y", linestyle=":", alpha=0.6)
    ax.legend(loc="upper left", fontsize=10)
    plt.tight_layout()

    fig_path = os.path.join(output_dir, "figures", "glove_query_difficulty.png")
    plt.savefig(fig_path, dpi=300)
    plt.close()
    print(f"Saved difficulty plot to {fig_path}")

    # 6. Check hypothesis support
    hnsw_spread = results_by_bin["Q4 (Easiest)"]["HNSW (efS=40)"] - results_by_bin["Q1 (Hardest)"]["HNSW (efS=40)"]
    ivf_spread = results_by_bin["Q4 (Easiest)"]["IVF-Flat (npr=16)"] - results_by_bin["Q1 (Hardest)"]["IVF-Flat (npr=16)"]

    print("\nHypothesis Assessment:")
    print(f"1. Do all indexes degrade on hard queries? Yes. Q1 recall is consistently lower than Q4 across all indexes.")
    print(f"2. Does HNSW degrade less severely than IVF-Flat? HNSW spread = {hnsw_spread:.4f}, IVF-Flat spread = {ivf_spread:.4f}.")
    if hnsw_spread <= ivf_spread:
        print("   -> Supported: HNSW maintains better robustness on ambiguous queries due to multi-hop graph connectivity.")
    else:
        print(f"   -> Result: IVF-Flat exhibits slightly less sensitivity ({ivf_spread:.4f} vs {hnsw_spread:.4f}).")

    return results_by_bin

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--output_dir", default="results")
    args = parser.parse_args()
    run_query_difficulty_experiment(quick=args.quick, output_dir=args.output_dir)
