"""
Metrics module for ANN Benchmarking.
Contains custom recall@k function with distance tie-handling at position k.
"""

import numpy as np

def recall_at_k(
    retrieved_ids: np.ndarray,
    ground_truth_ids: np.ndarray,
    retrieved_distances: np.ndarray = None,
    ground_truth_distances: np.ndarray = None,
    k: int = 10,
    eps: float = 1e-5,
) -> float:
    """
    Computes Recall@k with tie handling at the k-th neighbor.

    Args:
        retrieved_ids: Shape (k,) or (num_queries, k) - returned neighbor IDs.
        ground_truth_ids: Shape (k,) or (num_queries, k) - ground truth IDs.
        retrieved_distances: Optional shape (k,) or (num_queries, k) - distances of retrieved items.
        ground_truth_distances: Optional shape (k,) or (num_queries, k) - distances of ground truth items.
        k: Number of nearest neighbors to consider (default: 10).
        eps: Floating point tolerance for distance comparison.

    Returns:
        Average Recall@k across all queries (float between 0.0 and 1.0).
    """
    retrieved_ids = np.asarray(retrieved_ids)
    ground_truth_ids = np.asarray(ground_truth_ids)

    # Standardize to 2D: (num_queries, k)
    if retrieved_ids.ndim == 1:
        retrieved_ids = retrieved_ids[np.newaxis, :]
        ground_truth_ids = ground_truth_ids[np.newaxis, :]
        if retrieved_distances is not None:
            retrieved_distances = np.asarray(retrieved_distances)[np.newaxis, :]
        if ground_truth_distances is not None:
            ground_truth_distances = np.asarray(ground_truth_distances)[np.newaxis, :]

    num_queries = retrieved_ids.shape[0]
    total_recall = 0.0

    has_distances = (retrieved_distances is not None) and (ground_truth_distances is not None)

    for q in range(num_queries):
        ret_k = retrieved_ids[q, :k]
        gt_k_set = set(ground_truth_ids[q, :k])

        if not has_distances:
            # Standard recall without distance tie-breaking
            matches = sum(1 for idx in ret_k if idx in gt_k_set)
        else:
            # Tie handling at k-th neighbor:
            # Let max_gt_dist be the distance of the k-th ground truth neighbor.
            max_gt_dist = ground_truth_distances[q, k - 1]
            ret_dists = retrieved_distances[q, :k]

            matches = 0
            for idx, dist in zip(ret_k, ret_dists):
                if idx in gt_k_set:
                    matches += 1
                elif dist <= max_gt_dist + eps:
                    # Valid equidistant tie at or within the k-th neighbor distance
                    matches += 1

        total_recall += matches / float(k)

    return total_recall / float(num_queries)
