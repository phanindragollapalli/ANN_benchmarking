"""
Part 2: Benchmarking HNSW, IVF-Flat, and IVF-PQ on SIFT and GloVe.
- Sweeps build and search parameters.
- Single-thread, 1 query at a time, median timing over repetitions.
- Computes Recall@10, QPS, build time, index size, and bytes per vector.
- Saves results to results/results.csv and generates trade-off plots.
"""

import os
import sys
import time
import tempfile
import faiss
import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from src.data_loader import load_dataset
from src.metrics import recall_at_k

# Enforce single threading
faiss.omp_set_num_threads(1)
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"

def get_index_size_bytes(index) -> int:
    """Measure serialized size of index on disk."""
    with tempfile.NamedTemporaryFile(delete=True) as tmp:
        faiss.write_index(index, tmp.name)
        return os.path.getsize(tmp.name)

def build_index(index_type: str, d: int, train_vecs: np.ndarray, build_params: dict):
    """Builds and trains a FAISS index according to parameters."""
    t0 = time.perf_counter()

    if index_type == "HNSW":
        M = build_params.get("M", 32)
        efConstruction = build_params.get("efConstruction", 40)
        index = faiss.IndexHNSWFlat(d, M)
        index.hnsw.efConstruction = efConstruction
        index.add(train_vecs)

    elif index_type == "IVF-Flat":
        nlist = build_params.get("nlist", 1024)
        quantizer = faiss.IndexFlatL2(d)
        index = faiss.IndexIVFFlat(quantizer, d, nlist, faiss.METRIC_L2)
        index.train(train_vecs)
        index.add(train_vecs)

    elif index_type == "IVF-PQ":
        nlist = build_params.get("nlist", 1024)
        m_pq = build_params.get("m_pq", 16)
        nbits = build_params.get("nbits", 8)
        quantizer = faiss.IndexFlatL2(d)
        index = faiss.IndexIVFPQ(quantizer, d, nlist, m_pq, nbits)
        index.train(train_vecs)
        index.add(train_vecs)

    else:
        raise ValueError(f"Unknown index type {index_type}")

    build_time = time.perf_counter() - t0
    index_size = get_index_size_bytes(index)
    bytes_per_vec = index_size / float(len(train_vecs))

    return index, build_time, index_size, bytes_per_vec

def search_index(index, index_type: str, queries: np.ndarray, search_param: int, k: int = 10, reps: int = 3):
    """
    Executes search one query at a time, repeats 'reps' times, and takes median time.
    """
    if index_type == "HNSW":
        index.hnsw.efSearch = search_param
    elif index_type in ("IVF-Flat", "IVF-PQ"):
        index.nprobe = search_param

    num_queries = len(queries)
    # Warmup
    _ = index.search(queries[:5], k)

    times = []
    final_ids = np.empty((num_queries, k), dtype=np.int64)
    final_dists = np.empty((num_queries, k), dtype=np.float32)

    for r in range(reps):
        t0 = time.perf_counter()
        for i in range(num_queries):
            q = queries[i : i + 1]
            d, ids = index.search(q, k)
            if r == 0:
                final_dists[i] = d[0]
                final_ids[i] = ids[0]
        times.append(time.perf_counter() - t0)

    median_time = float(np.median(times))
    qps = num_queries / median_time if median_time > 0 else 0.0

    return final_ids, final_dists, qps, median_time

def benchmark_dataset(dataset_name: str, quick: bool = False, output_dir: str = "results"):
    """Runs complete benchmark of HNSW, IVF-Flat, and IVF-PQ on a dataset."""
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(os.path.join(output_dir, "figures"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "tables"), exist_ok=True)

    data = load_dataset(dataset_name, quick=quick)
    train_vecs = data["train"]
    queries = data["test_queries"]
    gt_neighbors = data["test_neighbors"]
    gt_distances = data["test_distances"]
    d = data["dimension"]

    print(f"\nBenchmarking {dataset_name.upper()} ({len(train_vecs):,} vectors, {len(queries):,} queries)...")

    # Define build settings and search sweeps
    if quick:
        hnsw_configs = [{"M": 16, "efConstruction": 40}]
        hnsw_searches = [10, 20, 40, 80]
        ivf_configs = [{"nlist": 256}]
        ivf_searches = [1, 4, 16, 64]
        m_pq = 16 if d == 128 else 10
        pq_configs = [{"nlist": 256, "m_pq": m_pq, "nbits": 8}]
        pq_searches = [1, 4, 16, 64]
    else:
        hnsw_configs = [
            {"M": 16, "efConstruction": 40},
            {"M": 32, "efConstruction": 100},
        ]
        hnsw_searches = [10, 16, 32, 64, 128, 256, 512]
        ivf_configs = [
            {"nlist": 256},
            {"nlist": 1024},
            {"nlist": 4096},
        ]
        ivf_searches = [1, 2, 4, 8, 16, 32, 64, 128]
        m_pq = 16 if d == 128 else 10
        m_pq_alt = 32 if d == 128 else 20
        pq_configs = [
            {"nlist": 1024, "m_pq": m_pq, "nbits": 8},
            {"nlist": 1024, "m_pq": m_pq_alt, "nbits": 8},
        ]
        pq_searches = [1, 2, 4, 8, 16, 32, 64, 128]

    all_results = []
    num_vecs = len(train_vecs)

    def compute_recall(ret_ids, ret_dists):
        if dataset_name == "sift":
            scaled = np.sqrt(np.maximum(ret_dists, 0.0))
        elif dataset_name == "glove":
            scaled = ret_dists / 2.0
        else:
            scaled = ret_dists
        return recall_at_k(ret_ids, gt_neighbors, scaled, gt_distances, k=10, eps=1e-3)

    # 1. HNSW Benchmark
    for b_conf in hnsw_configs:
        b_desc = f"M={b_conf['M']}_efC={b_conf['efConstruction']}"
        print(f"Building HNSW ({b_desc})...")
        idx, b_time, idx_sz, b_per_v = build_index("HNSW", d, train_vecs, b_conf)
        for ef_s in hnsw_searches:
            ids, dists, qps, t_med = search_index(idx, "HNSW", queries, ef_s)
            rec = compute_recall(ids, dists)
            res = {
                "dataset": dataset_name,
                "index_type": "HNSW",
                "build_params": b_desc,
                "search_param": ef_s,
                "recall_10": rec,
                "qps": qps,
                "latency_ms": (t_med / len(queries)) * 1000.0,
                "build_time_s": b_time,
                "index_size_mb": idx_sz / (1024 * 1024),
                "bytes_per_vector": b_per_v,
                "num_vectors": num_vecs,
            }
            all_results.append(res)
            print(f"  HNSW (M={b_conf['M']}, efS={ef_s:3d}): Recall@10={rec:.4f} | QPS={qps:7.1f}")

    # 2. IVF-Flat Benchmark
    for b_conf in ivf_configs:
        b_desc = f"nlist={b_conf['nlist']}"
        print(f"Building IVF-Flat ({b_desc})...")
        idx, b_time, idx_sz, b_per_v = build_index("IVF-Flat", d, train_vecs, b_conf)
        for npr in ivf_searches:
            if npr > b_conf["nlist"]:
                continue
            ids, dists, qps, t_med = search_index(idx, "IVF-Flat", queries, npr)
            rec = compute_recall(ids, dists)
            res = {
                "dataset": dataset_name,
                "index_type": "IVF-Flat",
                "build_params": b_desc,
                "search_param": npr,
                "recall_10": rec,
                "qps": qps,
                "latency_ms": (t_med / len(queries)) * 1000.0,
                "build_time_s": b_time,
                "index_size_mb": idx_sz / (1024 * 1024),
                "bytes_per_vector": b_per_v,
                "num_vectors": num_vecs,
            }
            all_results.append(res)
            print(f"  IVF-Flat (nlist={b_conf['nlist']}, nprobe={npr:3d}): Recall@10={rec:.4f} | QPS={qps:7.1f}")

    # 3. IVF-PQ Benchmark
    for b_conf in pq_configs:
        b_desc = f"nlist={b_conf['nlist']}_m={b_conf['m_pq']}"
        print(f"Building IVF-PQ ({b_desc})...")
        idx, b_time, idx_sz, b_per_v = build_index("IVF-PQ", d, train_vecs, b_conf)
        for npr in pq_searches:
            if npr > b_conf["nlist"]:
                continue
            ids, dists, qps, t_med = search_index(idx, "IVF-PQ", queries, npr)
            rec = compute_recall(ids, dists)
            res = {
                "dataset": dataset_name,
                "index_type": "IVF-PQ",
                "build_params": b_desc,
                "search_param": npr,
                "recall_10": rec,
                "qps": qps,
                "latency_ms": (t_med / len(queries)) * 1000.0,
                "build_time_s": b_time,
                "index_size_mb": idx_sz / (1024 * 1024),
                "bytes_per_vector": b_per_v,
                "num_vectors": num_vecs,
            }
            all_results.append(res)
            print(f"  IVF-PQ (m={b_conf['m_pq']}, nprobe={npr:3d}): Recall@10={rec:.4f} | QPS={qps:7.1f}")

    # 4. Measure Exact Search (Baseline point)
    print("Measuring Exact Baseline speed...")
    idx_exact = faiss.IndexFlatL2(d)
    idx_exact.add(train_vecs)
    # Warmup
    _ = idx_exact.search(queries[:5], 10)
    times_exact = []
    # Use 200 queries if full dataset to keep benchmark time practical
    exact_q = queries if quick else queries[:500]
    for _ in range(2):
        t0 = time.perf_counter()
        for i in range(len(exact_q)):
            _ = idx_exact.search(exact_q[i : i + 1], 10)
        times_exact.append(time.perf_counter() - t0)
    exact_qps = len(exact_q) / float(np.median(times_exact))
    print(f"Exact Search baseline QPS: {exact_qps:.1f}")

    # Save to CSV
    csv_path = os.path.join(output_dir, "results.csv")
    file_exists = os.path.exists(csv_path) and os.path.getsize(csv_path) > 0
    with open(csv_path, "a") as f:
        if not file_exists:
            f.write("dataset,index_type,build_params,search_param,recall_10,qps,latency_ms,build_time_s,index_size_mb,bytes_per_vector,num_vectors\n")
        for r in all_results:
            f.write(f"{r['dataset']},{r['index_type']},{r['build_params']},{r['search_param']},"
                    f"{r['recall_10']:.5f},{r['qps']:.2f},{r['latency_ms']:.3f},{r['build_time_s']:.2f},"
                    f"{r['index_size_mb']:.2f},{r['bytes_per_vector']:.2f},{r['num_vectors']}\n")

    # Generate Pareto Plot
    plot_tradeoff_curve(dataset_name, all_results, exact_qps, output_dir)

    return all_results

def get_pareto_frontier(points: list) -> list:
    """
    Computes Pareto frontier (best trade-off envelope) for (recall, QPS).
    Point A dominates Point B if recall_A >= recall_B and qps_A >= qps_B.
    """
    sorted_pts = sorted(points, key=lambda x: (x["recall_10"], x["qps"]))
    pareto = []
    for pt in sorted_pts:
        pareto = [p for p in pareto if not (pt["recall_10"] >= p["recall_10"] and pt["qps"] >= p["qps"])]
        if not any(p["recall_10"] >= pt["recall_10"] and p["qps"] >= pt["qps"] for p in pareto):
            pareto.append(pt)
    pareto.sort(key=lambda x: x["recall_10"])
    return pareto

def plot_tradeoff_curve(dataset_name: str, results: list, exact_qps: float, output_dir: str):
    """Plots Recall@10 vs QPS trade-off curves showing the Pareto frontier for each index and the exact baseline."""
    plt.figure(figsize=(9, 6.5))

    colors = {"HNSW": "#1f77b4", "IVF-Flat": "#2ca02c", "IVF-PQ": "#ff7f0e"}
    markers = {"HNSW": "o", "IVF-Flat": "s", "IVF-PQ": "^"}

    for itype in ["HNSW", "IVF-Flat", "IVF-PQ"]:
        pts = [r for r in results if r["index_type"] == itype]
        if not pts:
            continue

        # Plot individual configuration sweep curves in light dashed lines
        build_groups = set(r["build_params"] for r in pts)
        for b_param in sorted(build_groups):
            c_pts = [r for r in pts if r["build_params"] == b_param]
            c_pts.sort(key=lambda x: x["recall_10"])
            plt.plot(
                [r["recall_10"] for r in c_pts],
                [r["qps"] for r in c_pts],
                linestyle="--",
                alpha=0.35,
                linewidth=1.0,
                color=colors.get(itype),
            )

        # Plot Pareto frontier (Best envelope curve) prominently
        pareto_pts = get_pareto_frontier(pts)
        p_recalls = [r["recall_10"] for r in pareto_pts]
        p_qps = [r["qps"] for r in pareto_pts]
        plt.plot(
            p_recalls,
            p_qps,
            marker=markers.get(itype, "o"),
            markersize=6,
            linewidth=2.2,
            label=f"{itype} (Best Pareto Frontier)",
            color=colors.get(itype),
        )

    # Add Exact baseline
    plt.axhline(y=exact_qps, color="#d62728", linestyle=":", linewidth=1.8, label=f"Exact Baseline ({exact_qps:.0f} QPS)")
    plt.scatter([1.0], [exact_qps], color="#d62728", s=90, zorder=5, marker="X")

    plt.xlabel("Recall@10", fontsize=12, fontweight="bold")
    plt.ylabel("Queries Per Second (QPS)", fontsize=12, fontweight="bold")
    plt.title(f"Recall@10 vs. QPS Trade-off: {dataset_name.upper()} (Single Thread)", fontsize=13, fontweight="bold")
    plt.yscale("log")
    plt.xlim(0.25, 1.02)
    plt.grid(True, which="both", linestyle=":", alpha=0.6)
    plt.legend(loc="lower left", fontsize=10, framealpha=0.9)
    plt.tight_layout()

    fig_path = os.path.join(output_dir, "figures", f"{dataset_name}_tradeoff.png")
    plt.savefig(fig_path, dpi=300)
    plt.close()
    print(f"Saved trade-off plot to {fig_path}")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="sift", choices=["sift", "glove"])
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--output_dir", default="results")
    args = parser.parse_args()
    benchmark_dataset(args.dataset, quick=args.quick, output_dir=args.output_dir)
