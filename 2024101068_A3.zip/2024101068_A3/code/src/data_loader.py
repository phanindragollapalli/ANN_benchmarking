"""
Data loader and preprocessor for ANN Benchmarking.
Handles SIFT-1M and GloVe-100 datasets:
- Downloads .hdf5 files if not present.
- Normalizes GloVe vectors for Euclidean search.
- Splits queries into 5,000 validation (tuning) and 5,000 test.
"""

import os
import subprocess
import numpy as np
import h5py
import faiss

DATA_URLS = {
    "sift": "http://ann-benchmarks.com/sift-128-euclidean.hdf5",
    "glove": "http://ann-benchmarks.com/glove-100-angular.hdf5",
}

DATASET_FILENAMES = {
    "sift": "sift-128-euclidean.hdf5",
    "glove": "glove-100-angular.hdf5",
}

def get_data_dir():
    """Find or create data directory."""
    # Check if ../data exists (when running from code/)
    if os.path.isdir("../data"):
        return os.path.abspath("../data")
    if os.path.isdir("data"):
        return os.path.abspath("data")
    # Default to data/ at project root
    base = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "data"))
    os.makedirs(base, exist_ok=True)
    return base

DATASET_EXPECTED_SIZES = {
    "sift": 525128288,
    "glove": 485413888,
}

def download_dataset(dataset_name: str) -> str:
    """Download dataset if not already downloaded or incomplete."""
    data_dir = get_data_dir()
    filename = DATASET_FILENAMES[dataset_name]
    target_path = os.path.join(data_dir, filename)
    expected_size = DATASET_EXPECTED_SIZES.get(dataset_name)

    needs_download = False
    if not os.path.exists(target_path):
        needs_download = True
    elif expected_size and os.path.getsize(target_path) < expected_size:
        print(f"Dataset {dataset_name} incomplete ({os.path.getsize(target_path)} / {expected_size} bytes). Resuming...")
        needs_download = True

    if needs_download:
        url = DATA_URLS[dataset_name]
        print(f"Downloading {dataset_name} dataset from {url} to {target_path}...")
        # Use curl with resume flag -C -
        cmd = ["curl", "-L", "-C", "-", "-o", target_path, url]
        res = subprocess.run(cmd, check=True)
        if res.returncode != 0:
            raise RuntimeError(f"Failed to download {dataset_name} from {url}")
        print(f"Downloaded {dataset_name} ({os.path.getsize(target_path) / (1024*1024):.1f} MB)")
    else:
        print(f"Dataset {dataset_name} ready at {target_path} ({os.path.getsize(target_path) / (1024*1024):.1f} MB)")

    return target_path

def normalize_vectors(vecs: np.ndarray) -> np.ndarray:
    """L2 normalizes vectors along axis 1."""
    norms = np.linalg.norm(vecs, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return (vecs / norms).astype(np.float32)

def load_dataset(dataset_name: str, quick: bool = False):
    """
    Load dataset and return dictionary:
    - 'train': base vectors to index (N, d)
    - 'val_queries': first 5,000 queries for parameter tuning
    - 'test_queries': last 5,000 queries for final benchmark reporting
    - 'val_neighbors': ground truth neighbor IDs for val_queries
    - 'test_neighbors': ground truth neighbor IDs for test_queries
    - 'val_distances': ground truth distances for val_queries
    - 'test_distances': ground truth distances for test_queries
    """
    file_path = download_dataset(dataset_name)

    print(f"Loading {dataset_name} from {file_path}...")
    with h5py.File(file_path, "r") as f:
        train = np.array(f["train"], dtype=np.float32)
        queries = np.array(f["test"], dtype=np.float32)
        neighbors = np.array(f["neighbors"], dtype=np.int64)
        distances = np.array(f["distances"], dtype=np.float32)

    # Normalize GloVe vectors as required:
    # "Normalise the GloVe vectors and use Euclidean distance for everything."
    if dataset_name == "glove":
        print("Normalizing GloVe vectors to unit L2 length...")
        train = normalize_vectors(train)
        queries = normalize_vectors(queries)

    if quick:
        # Quick subset for --quick mode (first 100,000 base vectors, 1,000 queries)
        train = train[:100000]
        val_queries = queries[:500]
        test_queries = queries[500:1000]
        # Compute exact ground truth on the 100k subset for self-consistent recall benchmarking
        print("Computing exact ground truth for 100k subset in quick mode...")
        gt_index = faiss.IndexFlatL2(train.shape[1])
        gt_index.add(train)
        val_distances, val_neighbors = gt_index.search(val_queries, 100)
        test_distances, test_neighbors = gt_index.search(test_queries, 100)
        if dataset_name == "sift":
            val_distances = np.sqrt(np.maximum(val_distances, 0.0))
            test_distances = np.sqrt(np.maximum(test_distances, 0.0))
        elif dataset_name == "glove":
            val_distances = val_distances / 2.0
            test_distances = test_distances / 2.0
    else:
        # Standard: 5,000 tuning queries, 5,000 test queries
        val_queries = queries[:5000]
        test_queries = queries[5000:10000]
        val_neighbors = neighbors[:5000]
        test_neighbors = neighbors[5000:10000]
        val_distances = distances[:5000]
        test_distances = distances[5000:10000]

    print(f"Loaded {dataset_name}: {len(train):,} base vectors ({train.shape[1]}d), "
          f"{len(val_queries):,} tune queries, {len(test_queries):,} test queries.")

    return {
        "train": train,
        "val_queries": val_queries,
        "test_queries": test_queries,
        "val_neighbors": val_neighbors,
        "test_neighbors": test_neighbors,
        "val_distances": val_distances,
        "test_distances": test_distances,
        "dimension": train.shape[1],
    }

if __name__ == "__main__":
    # Test downloading and loading
    data_dir = get_data_dir()
    print(f"Data directory: {data_dir}")
